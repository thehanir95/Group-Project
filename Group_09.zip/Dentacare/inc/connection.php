<?php
//$connection=mysqli_connect(dbserver,dbuser,dbpass,dbname);

$dbhost='localhost';
$dbuser='root';
$dbpass='';
$dbname='dentacare';


$connection=mysqli_connect('localhost','root','','dentacare');

//Checking the connection
if (mysqli_connect_errno()) {
	die('Database Connection Failed.'.mysqli_connect_error());
}



?>